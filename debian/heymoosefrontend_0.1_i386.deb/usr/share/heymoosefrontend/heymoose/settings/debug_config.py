# configuration
MIN_POOL = 5
MAX_POOL = 4000
HOST = '127.0.0.1'
DATABASE = 'social_sampler'
DEBUG = True
DB_USER = 'qa'
DB_PASSWORD = 'appatit'
DB_PORT = 5432
DB_CHARSET = 'utf8'
SECRET_KEY = 'lola pola_mola_cola'
RESTAPI_SERVER = 'http://localhost:5468'
USE_DATABASE = True
print "ATTENTION DEBUG CONFIG IS USED"

