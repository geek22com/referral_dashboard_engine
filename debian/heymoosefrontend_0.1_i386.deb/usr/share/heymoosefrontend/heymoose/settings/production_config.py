# configuration
DEBUG = False
HOST = 'localhost'
DATABASE = 'social_sampler'
DB_USER = 'qa'
DB_PASSWORD = 'appatit'
DB_CHARSET = 'utf8'
SECRET_KEY = 'secret key'
