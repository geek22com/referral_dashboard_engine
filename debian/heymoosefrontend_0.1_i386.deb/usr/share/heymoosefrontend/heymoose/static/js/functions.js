function showTooltip()
{
	var myDiv = document.getElementById('tooltip');
	if(myDiv.style.display == 'none')
	{
		myDiv.style.display = 'block';
	} else {
		myDiv.style.display = 'none';
	}
		return false;
}

