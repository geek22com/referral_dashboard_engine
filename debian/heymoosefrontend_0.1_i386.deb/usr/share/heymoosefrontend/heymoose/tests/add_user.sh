#!/bin/bash
curl -X POST -i --data "passwordHash=qwe123&email=kaka1@kaka.com&nickname=kaka1" http://localhost:5468/users
