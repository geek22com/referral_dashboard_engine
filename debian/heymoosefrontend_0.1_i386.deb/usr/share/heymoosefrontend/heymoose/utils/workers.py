from heymoose import app

app_logger = app.logger
config = app.config
heymoose_app = app
