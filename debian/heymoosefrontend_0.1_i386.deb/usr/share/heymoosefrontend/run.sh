#!/bin/bash
python ./runserver.py
